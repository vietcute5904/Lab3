public class DVDVietHQ {
    // Khai báo thuộc tính
    private static int nbDigitalVideoDiscsVhq = 0;
    private int id;

    private String title;
    private String category;
    private String author;
    private int length;
    private float cost;

    // Các phương thức để chỉnh sửa thuộc tính của DVD
    public void setTitleVhq(String titleSet) { 
        title = titleSet; 
    }
    public void setCategoryVhq(String categorySet) { 
        category = categorySet; 
    }
    public void setAuthorVhq(String authorSet) { 
        author = authorSet; 
    }
    public void setLengthVhq(int lengthSet) { 
        length = lengthSet; 
    }
    public void setCostVhq(float costSet) { 
        cost = costSet; 
    }

    // Các phương thức của lớp DVD
    public String getTitleVhq() {
        return title;
    }
    public String getCategoryVhq() {
        return category;
    }
    public String getAuthorVhq() {
        return author;
    }
    public int getLengthVhq() {
        return length;
    }
    public float getCostVhq() {
        return cost;
    }
    public int getIDVhq() {
        return id;
    }

    // Create DVD by title
    public DVDVietHQ(String title) { 
        this.title = title;        
        this.id = ++nbDigitalVideoDiscsVhq;     
    }
    // Create DVD by title, category and price
    public DVDVietHQ(String title, String category, float cost) { 
        this(title);
        this.category = category;
        this.cost = cost; 
    }
    // Create DVD by title, category, price and author
    public DVDVietHQ(String title, String category, String author, float cost) { 
        this(title, category, cost);
        this.author = author;     
    }
    // Create DVD by title, category, price, author and length
    public DVDVietHQ(String title, String category, String author, int length, float cost) { 
        this(title, category, author, cost);
        this.length = length;
    }
    public boolean isMatch(String title) {
        return this.title.equalsIgnoreCase(title); // So sánh tiêu đề không phân biệt chữ hoa/thường
    }
}
