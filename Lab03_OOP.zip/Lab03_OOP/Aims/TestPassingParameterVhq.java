public class TestPassingParameterVietHQ {
    public static void main(String[] args){
        DVDVietHQ jungleDVD = new DVDVietHQ("Jungle");
        DVDVietHQ cinderellaDVD = new DVDVietHQ("Cinderella");

        swapCorrectVietHQ(jungleDVD, cinderellaDVD);

        System.out.println("Jungle dvd title: " + jungleDVD.getTitleVhq());
        System.out.println("Cinderella dvd title: " + cinderellaDVD.getTitleVhq());

        jungleDVD = changeTitleVietHQ(jungleDVD, cinderellaDVD.getTitleVhq());
        System.out.println("Jungle dvd title after change: " + jungleDVD.getTitleVhq());
        System.out.println("Bui Quang Hung 20225849");
    }

    public static void swapCorrectVietHQ(DVDVietHQ dvd1, DVDVietHQ dvd2) {
        DVDVietHQ tmp = new DVDVietHQ(
            dvd1.getTitleVhq(), 
            dvd1.getCategoryVhq(), 
            dvd1.getAuthorVhq(), 
            dvd1.getLengthVhq(), 
            dvd1.getCostVhq()
        );

        dvd1.setTitleVhq(dvd2.getTitleVhq());
        dvd1.setCategoryVhq(dvd2.getCategoryVhq());
        dvd1.setAuthorVhq(dvd2.getAuthorVhq());
        dvd1.setLengthVhq(dvd2.getLengthVhq());
        dvd1.setCostVhq(dvd2.getCostVhq());

        dvd2.setTitleVhq(tmp.getTitleVhq());
        dvd2.setCategoryVhq(tmp.getCategoryVhq());
        dvd2.setAuthorVhq(tmp.getAuthorVhq());
        dvd2.setLengthVhq(tmp.getLengthVhq());
        dvd2.setCostVhq(tmp.getCostVhq());
    }

    public static DVDVietHQ changeTitleVietHQ(DVDVietHQ dvd, String title) {
        String oldTitle = dvd.getTitleVhq();
        dvd.setTitleVhq(title);
        return new DVDVietHQ(oldTitle);  // Trả về đối tượng mới
    }
}
