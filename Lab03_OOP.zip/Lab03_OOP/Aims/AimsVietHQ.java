public class AimsVietHQ {
    public static void main(String[] args) {
        //Create new cart
        CartVietHQ anOrder = new CartVietHQ();

        //Create new DVD and add to cart
        DVDVietHQ DVD1 = new DVDVietHQ("Lion King", "Animation", "Roger Allers", 87, 19.95f);
        // anOrder.addDVDVhq(DVD1);
        DVDVietHQ DVD2 = new DVDVietHQ("Star Wars", "Science Fiction", "Geogre Lucas", 87,  24.95f);
        // anOrder.addDVDVhq(DVD2);
        DVDVietHQ DVD3 = new DVDVietHQ("Aladin", "Animation", 18.99f);
        // anOrder.addDVDVhq(DVD3);

        anOrder.addDVDVhq(DVD1, DVD2, DVD3);
        //Print total cost of DVDs in cart
        System.out.printf("Total cost is: %.2f $ \n", anOrder.totalCostVhq());

        // anOrder.listID();
        
        // System.out.println("\nSearching by Id:");
        // anOrder.searchByID(2); // Should find "Star Wars"
        // anOrder.searchByID(5); // Should not find any DVD

        // Search by Title
        // System.out.println("\nSearching by Title:");
        // anOrder.searchByTitle("Aladin"); // Should find "Aladin"
        // anOrder.searchByTitle("Frozen"); // Should not find any DVD

    }
}
