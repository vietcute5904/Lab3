public class CartTestVietHQ {
    public static void main(String[] args) {
        CartVietHQ cart = new CartVietHQ();
        
        DVDVietHQ dvd1 = new DVDVietHQ("The Lion King", "Animation",
                "Roger Allers", 87, 19.95f);
        cart.addDVDVhq(dvd1);
        
        DVDVietHQ dvd2 = new DVDVietHQ("Star wars", "Science Fiction",
                "Geogre Lucas", 87, 24.95f);
        cart.addDVDVhq(dvd2);
        
        DVDVietHQ dvd3 = new DVDVietHQ("Aladin", "Animation", 18.99f);
        cart.addDVDVhq(dvd3);

        cart.printCartVhq();

        // Test search by ID method
        cart.searchByIDVhq(3);
        cart.searchByIDVhq(4);

        // Test search by Title method
        cart.searchByTitleVhq("The Lion King");
        cart.searchByTitleVhq("Alan Walker");
    }
}
