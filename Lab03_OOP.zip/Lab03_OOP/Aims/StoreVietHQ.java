import java.util.ArrayList;
import java.util.List;

public class StoreVietHQ {
    // Attribute: danh sách động các đĩa DVD có sẵn trong cửa hàng
    private List<DVDVietHQ> itemsInStoreVhq;

    // Constructor để khởi tạo cửa hàng
    public StoreVietHQ() {
        itemsInStoreVhq = new ArrayList<>(); // Sử dụng ArrayList để thay đổi kích thước động
    }

    // Method to add a DVD to the store
    public void addDVDVhq(DVDVietHQ dvd) {
        if (dvd == null) {
            System.out.println("Cannot add a null DVD to the store.");
            return;
        }
        itemsInStoreVhq.add(dvd);
        System.out.println("The DVD \"" + dvd.getTitleVhq() + "\" has been added to the store!");
    }

    // Method to remove a DVD from the store 
    public void removeDVDVhq(DVDVietHQ dvd) {
        if (dvd == null) {
            System.out.println("Cannot remove a null DVD from the store.");
            return;
        }
        boolean found = false;
        for (DVDVietHQ storeDVD : itemsInStoreVhq) {
            if (storeDVD == dvd) {  
                itemsInStoreVhq.remove(storeDVD);
                System.out.println("The DVD \"" + storeDVD.getTitleVhq() + "\" has been removed from the store.");
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("No DVD found in the store that matches the given DVD.");
        }
    }
}
