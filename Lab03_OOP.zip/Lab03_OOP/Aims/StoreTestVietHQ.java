public class StoreTestVietHQ {
    public static void main(String[] args) {
        // Khởi tạo đối tượng cửa hàng
        StoreVietHQ myStore = new StoreVietHQ();

        // Khởi tạo các đối tượng DVD
        DVDVietHQ DVD1 = new DVDVietHQ("Lion King", "Animation", "Roger Allers", 87, 19.95f);
        myStore.addDVDVhq(DVD1);
        
        DVDVietHQ DVD2 = new DVDVietHQ("Star Wars", "Science Fiction", "Geogre Lucas", 87, 24.95f);
        myStore.addDVDVhq(DVD2);
        
        DVDVietHQ DVD3 = new DVDVietHQ("Aladin", "Animation", 18.99f);
        myStore.addDVDVhq(DVD3);

        // Xóa DVD từ cửa hàng
        myStore.removeDVDVhq(DVD2);
    }
}
